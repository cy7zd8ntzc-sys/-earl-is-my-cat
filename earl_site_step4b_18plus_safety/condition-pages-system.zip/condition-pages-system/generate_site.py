#!/usr/bin/env python3
"""
generate_site.py — Earl Is My Cat condition-page generator.

Single source of truth: conditions_data.json
Output: real, static .html files — same URLs as before (acne.html, rosacea.html,
etc.) plus a regenerated conditions.html directory page.

Why generate static files instead of rendering client-side from JSON:
this site is hosted statically on Cloudflare Pages with no backend. Static
HTML per condition keeps URLs unchanged (bookmarks/links/SEO intact) and keeps
the content itself crawlable, which matters for a health-education site.

Usage:
    python3 generate_site.py
    (writes into ./output/ — copy those files into the site repo to publish)

To change any condition's copy, edit conditions_data.json, then re-run this
script. A claims-language fix that used to mean editing ~22 files by hand is
now a one-line JSON edit + one script run.
"""
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
DATA_PATH = os.path.join(HERE, "conditions_data.json")
OUT_DIR = os.path.join(HERE, "output")

# ---------------------------------------------------------------------------
# Static chrome — identical on every page, copied verbatim from the real site.
# ---------------------------------------------------------------------------

HEAD_LINKS = (
    '<link href="https://fonts.googleapis.com" rel="preconnect"/>'
    '<link crossorigin="" href="https://fonts.gstatic.com" rel="preconnect"/>'
    '<link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,400..800&amp;family=Hanken+Grotesk:wght@400;500;600;700&amp;display=swap" rel="stylesheet"/>'
    '<link href="assets/css/condition.css" rel="stylesheet"/>'
)

LOGO_SVG = (
    '<svg fill="none" viewbox="0 0 26 26">'
    '<path d="M3 9 5 3l4 3.5h8L21 3l2 6v9a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V9Z" fill="#221F1B"></path>'
    '<circle cx="10" cy="13" fill="#3DA8AE" r="1.5"></circle>'
    '<circle cx="16" cy="13" fill="#3DA8AE" r="1.5"></circle>'
    '<path d="M13 16.5v1.5" stroke="#F6F3EE" stroke-linecap="round" stroke-width="1.4"></path>'
    '</svg>'
)

NAV = (
    '<header class="nav"><div class="wrap nav-in">'
    f'<a aria-label="Earl Is My Cat home" class="brand" href="index.html"><span aria-hidden="true" class="dot">{LOGO_SVG}</span>Earl Is My Cat</a>'
    '<nav aria-label="Primary" class="nav-links">'
    '<a href="index.html#how">How it works</a><a href="conditions.html">Conditions</a>'
    '<a href="otc.html">Shop</a><a href="pills.html">Supplements</a><a href="about.html">About</a>'
    '</nav>'
    '<a class="btn btn-primary" href="visit.html">Start a visit</a>'
    '</div></header>'
)

FOOTER = (
    '<footer><div class="wrap"><div class="foot-top">'
    f'<a class="brand" href="index.html"><span aria-hidden="true" class="dot">{LOGO_SVG}</span>Earl Is My Cat</a>'
    '<div class="foot-links">'
    '<a href="index.html#how">How it works</a><a href="conditions.html">Conditions</a>'
    '<a href="otc.html">Shop</a><a href="pills.html">Supplements</a><a href="about.html">About</a>'
    '<a href="visit.html">Start a visit</a>'
    '</div></div>'
    '<p class="disc">Earl Is My Cat provides general skin education and connects you with a '
    'board-certified dermatologist for online visits. It is not a substitute for in-person care '
    'and is not for emergencies. Products sold here are cosmetics and are not intended to '
    'diagnose, treat, cure, or prevent any disease. Prescription treatment, when appropriate, is '
    'determined by your physician during a visit. Educational information on this site is not '
    'individualized medical advice. Online visits are currently available only for adults 18 and '
    'older.</p>'
    '<p class="legal-links"><a href="terms.html">Terms</a>  ·  '
    '<a href="privacy.html">Privacy</a>  ·  '
    '<a href="consent.html">Telehealth Consent</a></p>'
    '<p class="wink">Earl is a cat. He is not a doctor. The doctor is a doctor.</p>'
    '</div></footer>'
    '<script defer="" src="assets/js/site.js"></script>'
)

# Decorative line-icon paths for the supporting-product swatches (24x24, matches
# the existing stroke="#20484C" stroke-width="1.6" minimalist style).
ICONS = {
    "drop":   '<path d="M12 3c4 5 6 8 6 11a6 6 0 1 1-12 0c0-3 2-6 6-11Z" stroke="#20484C" stroke-width="1.6"></path>',
    "clock":  '<circle cx="12" cy="12" r="8" stroke="#20484C" stroke-width="1.6"></circle><path d="M12 7v5l3 2" stroke="#20484C" stroke-linecap="round" stroke-width="1.6"></path>',
    "square": '<rect height="14" rx="7" stroke="#20484C" stroke-width="1.6" width="14" x="5" y="5"></rect>',
    "star":   '<path d="M12 3l1.9 5.2L19 10l-5.1 1.8L12 17l-1.9-5.2L5 10l5.1-1.8L12 3Z" stroke="#20484C" stroke-linejoin="round" stroke-width="1.6"></path>',
}


def esc(s: str) -> str:
    return (s or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def product_card(product_key: str, products: dict) -> str:
    p = products[product_key]
    icon_svg = ICONS.get(p.get("icon", ""), ICONS["drop"])
    return (
        '<div class="prod">'
        f'<div class="swatch"><svg fill="none" viewbox="0 0 24 24">{icon_svg}</svg></div>'
        f'<h3>{esc(p["name"])}</h3>'
        f'<p class="desc">{esc(p["desc"])}</p>'
        f'<div class="row"><span class="price">{esc(p["price"])}</span><span class="supp">{esc(p["supp"])}</span></div>'
        f'<a class="btn btn-warm add" href="{p["href"]}">{esc(p["cta"])}</a>'
        '</div>'
    )


def review_banner(cond: dict) -> str:
    """Visible (not just an HTML comment) flag for unreviewed draft content,
    using the site's existing .note-box style so it matches the design system.
    Delete this block (or flip status to "verified" and regenerate) once
    Dr. Eckert has reviewed the copy."""
    if cond.get("status") == "verified":
        return ""
    return (
        '<div class="wrap col"><div class="note-box">'
        '<b>Draft — not yet clinician-reviewed.</b> This page\'s content was drafted as a '
        'starting point and has not been reviewed by Dr. Eckert. Do not treat it as final '
        'medical copy until reviewed.'
        '</div></div>'
    )


def render_condition_page(cond: dict, products: dict) -> str:
    name = cond["name"]
    breadcrumb = cond.get("breadcrumb") or name
    helps_html = "".join(f"<li>{esc(x)}</li>" for x in cond["whatHelps"])
    skip_html = "".join(f"<li>{esc(x)}</li>" for x in cond["whatToSkip"])

    urgent = cond.get("urgentCare") or []
    urgent_html = (
        f"<h2>When to get in-person or urgent care</h2><ul>" +
        "".join(f"<li>{esc(x)}</li>" for x in urgent) + "</ul>"
    ) if urgent else ""

    prod_keys = cond.get("products", [])
    if prod_keys:
        prod_html = "".join(product_card(pk, products) for pk in prod_keys)
        prod_note = cond.get("prodNote")
        prod_note_html = f'<div class="prod-note">{prod_note}</div>' if prod_note else ""
        # Title/frame text is stored verbatim per condition (not auto-generated):
        # the real site has two different boilerplate variants across two
        # authoring generations, and the substitution inside Variant A isn't
        # perfectly mechanical (e.g. "fine lines or aging", not "& aging"),
        # so storing the resolved text avoids re-introducing that bug.
        supp_section = (
            '<section><div class="wrap col"><div class="supp-head">'
            f"<h2>{esc(cond['suppHeadTitle'])}</h2>"
            f"<p class=\"frame\">{esc(cond['suppHeadFrame'])}</p></div>"
            f'<div class="prod-grid">{prod_html}</div>{prod_note_html}</div></section>'
        )
    else:
        supp_section = ""

    meta_desc = cond.get("metaDescription") or cond["lead"]

    return f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"/><meta content="width=device-width, initial-scale=1.0" name="viewport"/><title>{esc(name)} — Earl Is My Cat</title><meta content="{esc(meta_desc)}" name="description"/>{HEAD_LINKS}</head><body class="page-condition">{NAV}<main><div class="wrap"><div class="col"><p class="breadcrumb"><a href="conditions.html">Conditions</a><span>/</span>{esc(breadcrumb)}</p></div></div><section class="cond-hero"><div class="wrap col"><p class="eyebrow">{esc(cond['category'])}</p><h1>{esc(name)}</h1><p class="lead">{esc(cond['lead'])}</p></div></section>{review_banner(cond)}<section class="edu"><div class="wrap col"><h2>What's actually going on</h2><p>{esc(cond['whatsGoingOn'])}</p><h2>What tends to help</h2><ul>{helps_html}</ul><h2>What I'd skip</h2><ul>{skip_html}</ul>{urgent_html}</div></section><section><div class="wrap col"><div class="consult" id="visit"><span class="badge">Talk to a dermatologist</span><h2>{esc(cond['consultQuestion'])}</h2><p>{esc(cond['consultBody'])}</p><a class="btn btn-primary" href="visit.html?c={cond['key']}">Start a visit</a></div></div></section>{supp_section}<section><div class="wrap col"><a class="back" href="conditions.html">← Back to all conditions</a></div></section></main>{FOOTER}</body></html>"""


def render_dir_card(cond: dict) -> str:
    # Note: the directory card headline (dirTitle) is intentionally its own
    # field, separate from `name` (used for the page H1/title) — the real
    # site uses different text in each place (e.g. rosacea's H1 is "Rosacea"
    # but its directory card reads "Rosacea & redness").
    return (
        f'<a class="dir-card" href="{cond["key"]}.html"><h3>{esc(cond["dirTitle"])}</h3>'
        f'<p>{esc(cond["dirBlurb"])}</p><span class="go">See what helps →</span></a>'
    )


def render_directory_page(data: dict) -> str:
    conditions = data["conditions"]
    common = [c for c in conditions if c["dirGroup"] == "common"]
    more = [c for c in conditions if c["dirGroup"] == "more"]
    common_html = "".join(render_dir_card(c) for c in common)
    more_html = "".join(render_dir_card(c) for c in more)

    return f"""<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8"/><meta content="width=device-width, initial-scale=1.0" name="viewport"/><title>Conditions — Earl Is My Cat</title><meta content="Skin, hair, nail, mouth, and sweat concerns treated online by a board-certified dermatologist." name="description"/>{HEAD_LINKS}</head>
<body class="page-condition">{NAV}<main><section class="page-head"><div class="wrap"><p class="eyebrow">What we help with</p><h1>Conditions</h1><p class="lead">Adult (18+) skin, hair, nail, mouth, and sweat concerns — reviewed by a board-certified dermatologist. Start with what fits, or start a visit and explain what is going on.</p></div></section><section><div class="wrap"><h2 class="section-label">Common online dermatology concerns</h2><div class="dir-grid">{common_html}</div><details class="more-conditions"><summary>More conditions</summary><div class="dir-grid">{more_html}</div></details><div class="note-box"><b>Adults only.</b> Online visits are currently available only for patients 18 and older. Pediatric and guardian-consent workflows are not part of this prototype.</div><div class="note-box"><b>Prescription options require a visit.</b> A prescription is never guaranteed. When prescription treatment is medically appropriate, it may be sent to a licensed third-party compounding pharmacy or another pharmacy depending on the treatment plan.</div><div class="note-box"><b>Supportive products are separate from treatment.</b> White-label OTC products and affiliate recommendations are positioned as supportive basics, not cures or treatments for disease.</div><p class="cta-spacer"><a class="btn btn-primary" href="visit.html">Start a visit</a></p></div></section></main>{FOOTER}</body></html>"""


def main():
    with open(DATA_PATH) as f:
        data = json.load(f)

    os.makedirs(OUT_DIR, exist_ok=True)

    for cond in data["conditions"]:
        html = render_condition_page(cond, data["products"])
        with open(os.path.join(OUT_DIR, f"{cond['key']}.html"), "w") as f:
            f.write(html)

    with open(os.path.join(OUT_DIR, "conditions.html"), "w") as f:
        f.write(render_directory_page(data))

    n = len(data["conditions"])
    draft_n = len([c for c in data["conditions"] if c["status"] != "verified"])
    print(f"Generated {n} condition pages + conditions.html into {OUT_DIR}/")
    print(f"  verified: {n - draft_n}   draft (needs clinician review): {draft_n}")


if __name__ == "__main__":
    main()
