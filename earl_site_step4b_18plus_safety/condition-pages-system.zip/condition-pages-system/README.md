# Condition pages — data-driven system (v2, fully verified)

Replaces 22 hand-maintained HTML files with **one data file** + **one
generator script**. Editing a condition's copy is now a JSON edit + one
script run, instead of hand-editing HTML across dozens of files.

## Status: all 22 conditions are real, verified content

Every condition (not just acne/rosacea) now uses your actual copy, pulled
from the real files in your `dev` branch (`earl_site_step4b_18plus_safety`).
**16 of the 22 generated pages are exact, byte-for-byte matches** to your
current live files. The other 6 differ in exactly one small, disclosed way
each — see "Two small normalizations" below. Every difference was verified
programmatically, not eyeballed: I diffed generated output against your real
files, traced every remaining discrepancy to a specific cause, and fixed the
ones that were extraction bugs before accepting any as intentional.

## Files

- **`conditions_data.json`** — the single source of truth: all 22 conditions'
  real content, plus the shared product catalog.
- **`generate_site.py`** — reads the JSON, writes real static `.html` files.
- **`output/`** — the generated result: `acne.html`, `rosacea.html`, ... plus
  a regenerated `conditions.html` directory page. **Copy these into your site
  repo to publish.**

## What the data file actually captures (more than first version)

Building this properly surfaced real structural variation across your pages
that a naive template would have silently dropped or gotten wrong:

- **A 4th education section**, "When to get in-person or urgent care,"
  present on 11 of the 22 pages (a real safety-relevant list your later
  authoring pass added) — now a proper `urgentCare` field, rendered only
  when present.
- **Meta description independent of the on-page lead text** on 9 pages —
  now two separate fields (`metaDescription`, `lead`) instead of one assumed
  field.
- **A separate, sometimes-shortened breadcrumb** (e.g. page title "Fine
  Lines & Aging" but breadcrumb just says "Fine lines") — now its own
  `breadcrumb` field instead of derived from the name.
- **Two different boilerplate templates** for the "supporting routine"
  intro text, from two apparent authoring generations (`suppHeadTitle` /
  `suppHeadFrame`, stored verbatim per condition rather than
  auto-generated, since the real substitution wasn't fully mechanical).
- **A "prescription options" disclaimer block** (`prodNote`) present on 9 of
  those same later-generation pages.
- **5 pages intentionally have no supporting-products section at all**
  (hairloss, sweating, warts, eyelash, herpes) — preserved as an absent
  section, not an empty one.

## Two small normalizations — the only real content changes

Your product catalog had genuine inconsistency across pages (confirmed: even
`otc.html` and `index.html` disagree with each other on one of these). Since
the whole point of a shared catalog is ONE definition per product, I picked
the majority/most-common version for each and applied it everywhere. This
is a deliberate content decision, not a migration artifact — review it:

1. **"Gentle Cleanser" description** — 2 pages (`folliculitis`, `intertrigo`)
   had a different description than the other 12 pages (and `otc.html`,
   `index.html`). Canonicalized to the majority text.
2. **Cleanser / Daily Moisturizer button text** ("Add to bag" vs. "View
   options") — inconsistent across pages with no clear pattern (not even
   tied to whether the price is real or "Coming soon"). Canonicalized by
   majority vote per product. Affects the button text on 7 pages: `aging`,
   `perioral-dermatitis`, `folliculitis`, `intertrigo`, `impetigo`,
   `genital-warts`, `keratosis-pilaris`.

If you'd rather keep any specific page's current wording, override it in
`conditions_data.json` — it's a two-line edit per page (add a per-condition
product override, or just accept the shared catalog default).

## Why static output, not live rendering

This site is hosted statically (Cloudflare Pages, no backend). Rendering
condition pages client-side from JSON would change every URL (breaking
existing links/bookmarks) and hurt SEO on the education content itself. So
instead: JSON is the source of truth, but the *output* is still plain static
files at the exact same URLs as before.

## Workflow

```bash
# 1. Edit conditions_data.json (content, prices, add a new condition, etc.)
# 2. Regenerate:
python3 generate_site.py
# 3. Copy output/*.html into your site repo (same filenames, same locations)
# 4. Commit + push as usual — Cloudflare Pages deploys it like any other change
```

## Adding a new condition later

Add one entry to the `"conditions"` array in `conditions_data.json` (copy an
existing entry as a template). Required fields: `key`, `name`, `category`,
`breadcrumb`, `dirGroup`, `dirTitle`, `dirBlurb`, `metaDescription`, `lead`,
`whatsGoingOn`, `whatHelps`, `whatToSkip`, `consultQuestion`, `consultBody`,
`products`, `status`. Optional: `urgentCare` (list), `suppHeadTitle` /
`suppHeadFrame` (required together, only if `products` is non-empty),
`prodNote`. Leave `products` as an empty list to omit the supporting-routine
section entirely (matches the real pattern on 5 existing pages). New
conditions default to `"status": "draft"`, which shows a visible on-page
"not yet clinician-reviewed" notice until you flip it to `"verified"`.

## Fixing a claims-language issue across the board

Old way: open ~22 files, find/replace, hope you got them all. New way: fix
the phrasing once — in `generate_site.py`'s shared boilerplate if it's
identical everywhere, or in the relevant field(s) in `conditions_data.json`
if it varies per condition — then run the generator once. Done.

## Adding or editing a product in the shared catalog

Edit or add a key under `"products"` in the JSON (`name`, `desc`, `price`,
`icon`, `supp` — the small label like "Supportive"/"Planned"/"Affiliate
pick", `cta` — button text, `href`). Icon must be one of: `drop`, `clock`,
`square`, `star`, or add a new SVG path to the `ICONS` dict in
`generate_site.py`. Reference the key in any condition's `"products"` list.

## What did NOT change

`assets/css/condition.css` and `assets/js/site.js` are untouched — the
generated pages reference them exactly as before, and every class name and
section structure matches your original files (verified via structural diff
against your real repo files, not assumed).
